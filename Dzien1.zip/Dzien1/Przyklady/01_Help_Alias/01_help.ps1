﻿$PSVersionTable

#Help
Get-Help *net* -Category cmdlet
Get-help Get-ChildItem -ShowWindow
Get_help  *process
Get-Help *process*


#Finding (Get-command)
Get-Command *net*
Get-Command -Verb Get -Noun event* 
