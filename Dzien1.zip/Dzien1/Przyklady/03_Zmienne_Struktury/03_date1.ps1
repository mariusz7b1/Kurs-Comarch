﻿$date = Get-Date


$date
$date.Hour
$date.Minute
$date.Day
$date.DayOfWeek
$date.Month
$date.Year


$date.AddDays(100)
$date.AddDays(-60)


$date.ToLongDateString()
$date.ToShortDateString()
$date.ToLongTimeString()
$date.ToShortTimeString()
