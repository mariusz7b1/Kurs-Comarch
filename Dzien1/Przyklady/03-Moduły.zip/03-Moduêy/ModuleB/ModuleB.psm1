﻿
function Get-FromModuleB {
    "Jestem funkcją z ModuleB"
}
Export-ModuleMember -Function Get-FromModuleB
