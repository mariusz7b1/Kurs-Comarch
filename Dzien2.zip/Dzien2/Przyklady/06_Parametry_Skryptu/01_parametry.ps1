﻿Param (
    [string]$ComputerName
    
)

Write-Host "Wartość parametru 'ComputerName' to:" -NoNewline -BackgroundColor Black -ForegroundColor Green
Write-Host  $ComputerName -BackgroundColor Black -ForegroundColor Cyan
